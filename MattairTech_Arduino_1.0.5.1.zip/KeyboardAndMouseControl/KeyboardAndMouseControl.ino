
/*
  KeyboardAndMouseControl
 
 Controls the mouse from five pushbuttons on an Arduino Leonardo or Micro.
 
 Hardware:
 * 5 pushbuttons attached to pins 18-22
 
 
 The mouse movement is always relative. This sketch reads 
 four pushbuttons, and uses them to set the movement of the mouse.
 
 WARNING:  When you use the Mouse.move() command, the Arduino takes
 over your mouse!  Make sure you have control before you use the mouse commands.
 
 created 15 Mar 2012
 modified 27 Mar 2012
 by Tom Igoe
 
 this code is in the public domain
 
 */

// set pin numbers for the five buttons:
const int upButton = 18;     
const int downButton = 19;        
const int leftButton = 20;
const int rightButton = 21;
const int mouseButton = 22;

void setup() { // initialize the buttons' inputs:
  pinMode(upButton, INPUT_PULLUP);       
  pinMode(downButton, INPUT_PULLUP);       
  pinMode(leftButton, INPUT_PULLUP);       
  pinMode(rightButton, INPUT_PULLUP);       
  pinMode(mouseButton, INPUT_PULLUP);
  
  Serial.begin(9600);
  Mouse.begin();
  Keyboard.begin();
}

void loop() {
  // use serial input to control the mouse:
  if (Serial.available() > 0) {
    char inChar = Serial.read();

    switch (inChar) {   
    case 'u':
      // move mouse up
      Mouse.move(0, -1);
      break; 
    case 'd':
      // move mouse down
      Mouse.move(0, 1);
      break;
    case 'l':
      // move mouse left
      Mouse.move(-1, 0);
      break;
    case 'r':
      // move mouse right
      Mouse.move(1, 0);
      break;
    case 'm':
      // perform mouse left click
      Mouse.click(MOUSE_LEFT);
      break;
    }
  }

  // use the pushbuttons to control the keyboard:
  if (digitalRead(upButton) == LOW) {
    Keyboard.write('u'); 
  }
  if (digitalRead(downButton) == LOW) {
    Keyboard.write('d'); 
  }
  if (digitalRead(leftButton) == LOW) {
    Keyboard.write('l'); 
  }
  if (digitalRead(rightButton) == LOW) {
    Keyboard.write('r'); 
  }
  if (digitalRead(mouseButton) == LOW) {
    Keyboard.write('m'); 
  }

}

