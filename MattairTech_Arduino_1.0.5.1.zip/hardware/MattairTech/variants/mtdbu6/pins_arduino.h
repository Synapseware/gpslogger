/*
  pins_arduino.h - Pin definition functions for Arduino
  Part of Arduino - http://www.arduino.cc/

  Copyright (c) 2007 David A. Mellis

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General
  Public License along with this library; if not, write to the
  Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

  $Id: wiring.h 249 2007-02-03 16:52:51Z mellis $
*/


/*
  Modified 15 March 2013 by Justin Mattair
     for MattairTech MT-DB-U6 boards (www.mattairtech.com)
*/

#ifndef Pins_Arduino_h
#define Pins_Arduino_h

#include <avr/pgmspace.h>

#define TX_RX_LED_INIT          DDRE |= (1<<0)
#define TXLED1                  PORTE |= (1<<0)
#define TXLED0                  PORTE &= ~(1<<0)
#define RXLED1                  PORTE |= (1<<0)
#define RXLED0                  PORTE &= ~(1<<0)

static const uint8_t LED_BUILTIN = 0;

static const uint8_t SDA = 30;
static const uint8_t SCL = 29;

static const uint8_t SS   = 19;
static const uint8_t MOSI = 21;
static const uint8_t MISO = 22;
static const uint8_t SCK  = 20;

// Mapping of analog pins as digital I/O
// Note that all pins are supported for digital I/O and analog out
// Note that all pins are supported for analog reading as well,
// however, if no physical ADC input exists on the pin, then either
// a ground measurement is returned, or, in the case of
// pin 47, the internal reference is read.
static const uint8_t A0 = 0;    // GND (shared with LED)
static const uint8_t A1 = 1;    // GND
static const uint8_t A2 = 2;    // GND
static const uint8_t A3 = 3;    // GND
static const uint8_t A4 = 4;    // GND
static const uint8_t A5 = 5;    // GND
static const uint8_t A6 = 6;    // GND
static const uint8_t A7 = 7;    // GND
static const uint8_t A8 = 8;    // GND
static const uint8_t A9 = 9;    // GND
static const uint8_t A10 = 10;  // ADC7
static const uint8_t A11 = 11;  // ADC6
static const uint8_t A12 = 12;  // ADC5
static const uint8_t A13 = 13;  // ADC4
static const uint8_t A14 = 14;  // ADC3
static const uint8_t A15 = 15;  // ADC2
static const uint8_t A16 = 16;  // ADC1
static const uint8_t A17 = 17;  // ADC0
static const uint8_t A18 = 18;  // GND (optional power supply status/control line, pin E6)
static const uint8_t A19 = 19;  // GND
static const uint8_t A20 = 20;  // GND
static const uint8_t A21 = 21;  // GND
static const uint8_t A22 = 22;  // GND
static const uint8_t A23 = 23;  // GND
static const uint8_t A24 = 24;  // GND
static const uint8_t A25 = 25;  // GND
static const uint8_t A26 = 26;  // GND
static const uint8_t A27 = 27;  // GND
static const uint8_t A28 = 28;  // GND
static const uint8_t A29 = 29;  // GND
static const uint8_t A30 = 30;  // GND
static const uint8_t A31 = 31;  // GND
static const uint8_t A32 = 32;  // GND
static const uint8_t A33 = 33;  // GND
static const uint8_t A34 = 34;  // GND
static const uint8_t A35 = 35;  // GND
static const uint8_t A36 = 36;  // GND
static const uint8_t A37 = 37;  // GND (shared with Jumper)
static const uint8_t A38 = 38;  // GND
static const uint8_t A39 = 39;  // GND
static const uint8_t A40 = 40;  // GND
static const uint8_t A41 = 41;  // GND
static const uint8_t A42 = 42;  // GND
static const uint8_t A43 = 43;  // GND
static const uint8_t A44 = 44;  // GND
static const uint8_t A45 = 45;  // GND
static const uint8_t A46 = 46;  // GND (RTC crystal, pin E4)
static const uint8_t A47 = 47;  // internal voltage reference (RTC crystal, pin E5)

extern const uint8_t PROGMEM analog_pin_to_channel_PGM[];
#define analogPinToChannel(P)  ( pgm_read_byte( analog_pin_to_channel_PGM + (P) ) )

#define NUM_DIGITAL_PINS            48
#define NUM_ANALOG_INPUTS           48
#define analogInputToDigitalPin(p)  (p)

// Including Timer 0
#if defined(USE_RTC)
#define digitalPinHasPWM(p)         ((p) == 6 || (p) == 7 || (p) == 8 || (p) == 24 || (p) == 25 || (p) == 26 || (p) == 29)
#else
#define digitalPinHasPWM(p)         ((p) == 6 || (p) == 7 || (p) == 8 || (p) == 23 || (p) == 24 || (p) == 25 || (p) == 26 || (p) == 29 || (p) == 30)
#endif

// PCINT 0-7 are on pins 19-26
#define digitalPinToPCICR(p)    ( (((p) >= 19) && ((p) <= 26)) ? (&PCICR) : ((uint8_t *)0) )
#define digitalPinToPCICRbit(p) 0
#define digitalPinToPCMSK(p)    ( (((p) >= 19) && ((p) <= 26)) ? (&PCMSK0) : ((uint8_t *)0) )
#define digitalPinToPCMSKbit(p) ( (((p) >= 19) && ((p) <= 26)) ? ((p) - 19) : 0 )

#ifdef ARDUINO_MAIN

// these arrays map port names (e.g. port B) to the
// appropriate addresses for various functions (e.g. reading
// and writing)
const uint16_t PROGMEM port_to_mode_PGM[] = {
	NOT_A_PORT,
	(uint16_t) &DDRA,
	(uint16_t) &DDRB,
	(uint16_t) &DDRC,
	(uint16_t) &DDRD,
	(uint16_t) &DDRE,
	(uint16_t) &DDRF,
};

const uint16_t PROGMEM port_to_output_PGM[] = {
	NOT_A_PORT,
        (uint16_t) &PORTA,
	(uint16_t) &PORTB,
	(uint16_t) &PORTC,
	(uint16_t) &PORTD,
	(uint16_t) &PORTE,
	(uint16_t) &PORTF,
};

const uint16_t PROGMEM port_to_input_PGM[] = {
	NOT_A_PORT,
	(uint16_t) &PINA,
	(uint16_t) &PINB,
	(uint16_t) &PINC,
	(uint16_t) &PIND,
	(uint16_t) &PINE,
	(uint16_t) &PINF,
};

const uint8_t PROGMEM digital_pin_to_port_PGM[48] = {
        PE, /* 0, LED */
        PE,
        PC, /* 2 */
        PC,
        PC,
        PC,
        PC,
        PC,
        PC,
        PC,
        PF, /* 10 */
        PF,
        PF,
        PF,
        PF,
        PF,
        PF,
        PF,
        PE, /* 18 */
        PB, /* 19 */
        PB,
        PB,
        PB,
        PB,
        PB,
        PB,
        PB,
        PE, /* 27 */
        PE,
        PD, /* 29 */
        PD,
        PD,
        PD,
        PD,
        PD,
        PD,
        PD,
        PE, /* 37, Jumper */
        PA, /* 38 */
        PA,
        PA,
        PA,
        PA,
        PA,
        PA,
        PA,
        PE, /* 46, RTC crystal */
        PE, /* 47, RTC crystal */
};

const uint8_t PROGMEM digital_pin_to_bit_mask_PGM[48] = {
        _BV(0),
        _BV(1),
        _BV(0),
        _BV(1),
        _BV(2),
        _BV(3),
        _BV(4),
        _BV(5),
        _BV(6),
        _BV(7),
        _BV(7),
        _BV(6),
        _BV(5),
        _BV(4),
        _BV(3),
        _BV(2),
        _BV(1),
        _BV(0),
        _BV(6),
        _BV(0),
        _BV(1),
        _BV(2),
        _BV(3),
        _BV(4),
        _BV(5),
        _BV(6),
        _BV(7),
        _BV(7),
        _BV(3),
        _BV(0),
        _BV(1),
        _BV(2),
        _BV(3),
        _BV(4),
        _BV(5),
        _BV(6),
        _BV(7),
        _BV(2),
        _BV(0),
        _BV(1),
        _BV(2),
        _BV(3),
        _BV(4),
        _BV(5),
        _BV(6),
        _BV(7),
        _BV(4),
        _BV(5),
};

const uint8_t PROGMEM digital_pin_to_timer_PGM[48] = {
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        TIMER3C,
        TIMER3B,
        TIMER3A,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        TIMER2A,
        TIMER1A,
        TIMER1B,
        TIMER1C,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        TIMER0B,
        TIMER2B,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
        NOT_ON_TIMER,
};

// These are the actual MUX bits from the datasheet
#define ADC0 0
#define ADC1 1
#define ADC2 2
#define ADC3 3
#define ADC4 4
#define ADC5 5
#define ADC6 6
#define ADC7 7
#define REFERENCE 30
#define GROUND 31

// Returns the MUX bits for the MT-DB-U4 ADC, not the channel
const uint8_t PROGMEM analog_pin_to_channel_PGM[48] = {
	  GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        ADC7,
        ADC6,
        ADC5,
        ADC4,
        ADC3,
        ADC2,
        ADC1,
        ADC0,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        GROUND,
        REFERENCE,
};

#endif /* ARDUINO_MAIN */
#endif /* Pins_Arduino_h */
