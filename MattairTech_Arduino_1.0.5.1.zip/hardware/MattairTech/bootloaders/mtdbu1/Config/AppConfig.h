/*
             LUFA Library
     Copyright (C) Dean Camera, 2013.

  dean [at] fourwalledcubicle [dot] com
           www.lufa-lib.org
*/

/*
  Copyright 2013  Dean Camera (dean [at] fourwalledcubicle [dot] com)

  Permission to use, copy, modify, distribute, and sell this
  software and its documentation for any purpose is hereby granted
  without fee, provided that the above copyright notice appear in
  all copies and that both that the copyright notice and this
  permission notice and warranty disclaimer appear in supporting
  documentation, and that the name of the author not be used in
  advertising or publicity pertaining to distribution of the
  software without specific, written prior permission.

  The author disclaims all warranties with regard to this
  software, including all implied warranties of merchantability
  and fitness.  In no event shall the author be liable for any
  special, indirect or consequential damages or any damages
  whatsoever resulting from loss of use, data or profits, whether
  in an action of contract, negligence or other tortious action,
  arising out of or in connection with the use or performance of
  this software.
*/

/** \file
 *  \brief Application Configuration Header File
 *
 *  This is a header file which is be used to configure LUFA's
 *  compile time options, as an alternative to the compile time
 *  constants supplied through a makefile.
 *
 *  For information on what each token does, refer to the 
 *  \ref Sec_Options section of the application documentation.
 */

#ifndef _APP_CONFIG_H_
#define _APP_CONFIG_H_

//	#define NO_BLOCK_SUPPORT
//	#define NO_EEPROM_BYTE_SUPPORT
//	#define NO_FLASH_BYTE_SUPPORT
	#define NO_LOCK_BYTE_WRITE_SUPPORT
        
        #define ENABLE_LED_BOOT
        #define ENABLE_LED_APPLICATION
        #define DISABLE_JTAG_APPLICATION
        #define ENABLE_CLKDIV_1_APPLICATION
        #define ENABLE_BOOT_KEY
        #define ENABLE_RESET_AFTER_PROGRAMMING

#endif