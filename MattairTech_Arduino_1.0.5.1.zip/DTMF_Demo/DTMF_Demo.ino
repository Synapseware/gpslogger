// DTMF Demo for MT-DB-xx boards
// The MT-DB-U1 and MT-DB-U2 will use timer 1 and timer 0
// The MT-DB-U4 and MT-DB-U6 will use timer 1 and timer 3

const int DTMF_freq1[] = { 1336, 1209, 1336, 1477, 1209, 1336, 1477, 1209, 1336, 1477 };
const int DTMF_freq2[] = {  941,  697,  697,  697,  770,  770,  770,  852,  852,  852 };

void setup()
{
  Serial.begin( USB_LED_ENABLED | USB_AUTOFLUSH_ENABLED );
}

void playDTMF(uint8_t number, long duration)
{
  tone(11, DTMF_freq1[number], duration);
  tone(12, DTMF_freq2[number], duration);
}


void loop()
{
  uint8_t i;
  uint8_t phone_number[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 };

  for(i = 0; i < sizeof(phone_number); i ++)
  {
    Serial.print(phone_number[i], 10);
    Serial.print(' ');
    Serial.flush();    // must manually flush upstream USB buffer if timer 0 is used by tone()
    playDTMF(phone_number[i], 500);
    _delay_ms(600);    // must use _delay_ms() from avr-libc if timer 0 is used by tone()
    // If using timer 0 for tone(), USB autoflushing, USB LED handling, and delay() will return to normal operation after the tone stops
  }
 
  Serial.println();
  // it is OK to use delay() here because no tones are being generated (and thus possibly using timer 0, which is needed by delay())
  delay(4000);
}

