/*
  Software serial multple serial test
 
 Receives from the two software serial ports, 
 sends to the hardware serial port. 
 
 In order to listen on a software port, you call port.listen(). 
 When using two software serial ports, you have to switch ports
 by listen()ing on each one in turn. Pick a logical time to switch
 ports, like the end of an expected transmission, or when the 
 buffer is empty. This example switches ports when there is nothing
 more to read from a port
 
 The circuit: 
 Two devices which communicate serially are needed.
 * First serial device's TX attached to digital pin 2, RX to pin 3
 * Second serial device's TX attached to digital pin 4, RX to pin 5
  
 Note:
 Not all pins on the Mega and Mega 2560 support change interrupts, 
 so only the following can be used for RX: 
 10, 11, 12, 13, 50, 51, 52, 53, 62, 63, 64, 65, 66, 67, 68, 69
 
 Not all pins on the Leonardo support change interrupts, 
 so only the following can be used for RX: 
 8, 9, 10, 11, 14 (MISO), 15 (SCK), 16 (MOSI).

 Not all pins on the MT-DB-xx boards support pin change interrupts, 
 so only the following can be used for RX: 
 MT-DB-U1/U2:	0 (SS), 1 (SCK), 2 (MOSI), 3 (MISO), 4, 5, 6, 7, 9, 10, 11, 12, 18.
 MT-DB-U4:	0, 1, 2, 13 (SS), 14 (MISO), 15 (SCK), 16 (MOSI), 17.
 MT-DB-U6:	19 (SS), 20 (SCK), 21 (MOSI), 22 (MISO), 23, 24, 25, 26.

 created 18 Apr. 2011
 modified 25 May 2012
 by Tom Igoe
 based on Mikal Hart's twoPortRXExample
 
 This example code is in the public domain.
 
 */

#include <SoftwareSerial.h>
// software serial #1: TX = digital pin 2, RX = digital pin 3
SoftwareSerial portOne(2, 3);

// software serial #2: TX = digital pin 0, RX = digital pin 1
// on the Mega, use other pins instead, since 8 and 9 don't work on the Mega
SoftwareSerial portTwo(0, 1);

void setup()
{
 // Open serial communications and wait for port to open:
  Serial.begin(9600);
   while (!Serial) {
    ; // wait for serial port to connect. Needed for Leonardo only
  }


  // Start each software serial port
  portOne.begin(9600);
  portTwo.begin(9600);
}

void loop()
{
  // By default, the last intialized port is listening.
  // when you want to listen on a port, explicitly select it:
  portOne.listen();
  Serial.println("Data from port one:");
  // while there is data coming in, read it
  // and send to the hardware serial port:
  while (portOne.available() > 0) {
    char inByte = portOne.read();
    Serial.write(inByte);
  }

  // blank line to separate data from the two ports:
  Serial.println();

  // Now listen on the second port
  portTwo.listen();
  // while there is data coming in, read it
  // and send to the hardware serial port:
  Serial.println("Data from port two:");
  while (portTwo.available() > 0) {
    char inByte = portTwo.read();
    Serial.write(inByte);
  }

  // blank line to separate data from the two ports:
  Serial.println();
}
